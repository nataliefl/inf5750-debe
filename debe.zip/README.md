#Data Elements Bulk Editor

[Wiki](https://wiki.uio.no/mn/ifi/inf5750/index.php/Stack_workers)

##API Endpoints
[dataElements](http://inf5750-21.uio.no/api/dataElements)

