Wiki : https://wiki.uio.no/mn/ifi/inf5750/index.php/Stack_workers
Trello : https://trello.com/b/QeREON8M/debe
DHIS group page : http://inf5750-21.uio.no/
DHIPS group API page : http://inf5750-21.uio.no/api/dataElements

